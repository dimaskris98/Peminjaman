<?php
class mod_Peminjaman extends CI_Model {
	function __construct() {
		
	}
	
}
?>