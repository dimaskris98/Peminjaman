<header>
    	<div id="logo"><a href="<?php echo base_url(); ?>"><img src="<?php echo base_url(); ?>assets/images/logo-politeknik-negeri-jember.png" width="400" height="400"></a></div>
        <div id="nama"><span class="nama">Peminjaman Gedung</span><br>
        <span class="aipni">Politeknik Negeri Jember</span></div>
  </header>

<nav>

  </nav>