<div class="clearfix"></div>
    <footer>Website Peminjaman Gedung | Politeknik Negeri Jember</footer></div>
</body>
</html>