<div class="konten">
    	<div class="slider"><img src="<?php echo base_url('assets/images/images.png'); ?>" width="624" height="326"></div>
        <div class="anggota">
          <h3>Login</h3>
          <form action="<?php echo base_url('home/cek_login'); ?>" name="form2" method="POST" action="/dyah/index.php">
            <p>
              <label for="email">Username</label>
              <input type="text" name="username" >
            </p>
            <p>
              <label for="password">Password</label>
              <input type="password" name="password">
            </p>
            <p>
              <input type="submit" name="submit2" value="Masuk">
              
            </p>
            
          </form>
      </div>    
  </div>
 
      
        