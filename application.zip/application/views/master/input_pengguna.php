<html>
	<head>
		<title>Input</title>
	</head>
	<body>
		<h4 align="center">Tambah Data Pengguna</h4>
		<div align="center">
		<p>
			<form method="post" action="input">
        NIM<br/><input type="text" name="NIM" ><br/><br/>
		
        Nama<br/><input type="text" name="nama_pengguna"  ><br/><br/>
		
		
        No HP <br/><input type="text" name="noHp_pengguna"  ><br/><br/>
        Jenis Kelamin <br/><select name="jk_pengguna">
                <option value="pria">Pria</option>
                <option value="wanita">Wanita</option></select><br/><br/>
        password <br/><input type="text" name="password"  ><br/><br/>
        Alamat <br/><input type="text" name="alamat_pengguna"  ><br/><br/>
		
        
		<br/><br/>
        <input type="submit" name="submit" value="Simpan" />
    </form>
		</p>
		</div>
	</body>
</html>