<html>
	<head>

		<title>Input</title>
		<style>
			.separuh {
				width : 30%;
			}
		</style>
	</head>
	<body>
	<br>
		<h4 align="center">Tambah Data Pengguna</h4>
		<br>
		<div align="center">
		
		<p>
			<form method="post" action="input">
			<div class="form-group">
			<input class="form-control separuh" placeholder="ID_Fasilitas" name="ID_Fasilitas" type="text" autofocus>
			<br>
			<input class="form-control separuh" placeholder="Nama Fasilitas" name="Nama_Fasilitas" type="text" autofocus>

        
		<br/><br/>
        <input type="submit" name="submit" value="Simpan" />
    </form>
		</p>
		</div>
	</body>
</html>
