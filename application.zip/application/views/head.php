<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title><?php echo $title ?>.</title>
<link href="<?php echo base_url(); ?>assets/css/style.css" rel="stylesheet" type="text/css">
</head>

<body>
<div id="wrapper">