<html>
	<head>
		<title>Input</title>
		<style>
			.separuh {
				width : 30%;
			}
		</style>
	</head>
	<body>
	<br>
		<h4 align="center">Tambah Data Petugas</h4>
		<br>
		<div align="center">
		<p>
			<form method="post" action="input">
			<input class="form-control separuh" placeholder="NIP" name="NIP" type="text" autofocus>
        <br>
       
		<input class="form-control separuh" placeholder="Nama" name="Nama" type="text" autofocus>
        <br>
        
		<input class="form-control separuh" placeholder=" No HP" name="NoHp_Pegawai" type="text" autofocus>
        <br>
		
        
		<input class="form-control separuh" placeholder="ID_Gedung" name="ID_Gedung" type="text" autofocus>
        <br>
        Jenis Kelamin <br/><select name="JK_Pegawai">
                <option value="pria">Pria</option>
                <option value="wanita">Wanita</option></select><br/><br/>
				
				<input class="form-control separuh" placeholder="password" name="Password" type="text" autofocus>
        <br>
        
		<input class="form-control separuh" placeholder="Alamat" name="Alamat_Pegawai" type="text" autofocus>
        <br>
        
        
		
        <input type="submit" name="submit" value="Simpan" />
    </form>
		</p>
		</div>
	</body>
</html>