<html>
	<head>
		<title>Input</title>
		<style>
			.separuh {
				width : 30%;
			}
		</style>
	</head>
	<body>
	<br>
		<h4 align="center">Tambah Data Gedung</h4>
		<br>
		<div align="center">
		<p>
			<form method="post" action="input">
			<input class="form-control separuh" placeholder="ID_Gedung" name="ID_Gedung" type="text" autofocus>
        <br>
		<input class="form-control separuh" placeholder="Nama_Gedung" name="Nama_Gedung" type="text" autofocus>
       <br>
		<input class="form-control separuh" placeholder="Deskripsi" name="Deskripsi" type="text" autofocus>
        <br>
        <input class="form-control separuh" placeholder="NIP" name="NIP" type="text" autofocus>
         <br>
        <input type="submit" name="submit" value="Simpan" />
    </form>
		</p>
		</div>
	</body>
</html>